// The isolated-world half of the extension, in every frame.
//
// It puts shim.js into the page's own world, carries the shim's requests to
// background.js and the answers back, and draws the permission prompt in
// the top frame.  Bytes cross to the background as base64: Safari's
// extension messaging is JSON, the page's side is Uint8Arrays.
'use strict';
(function () {
    if (window.__webmidiContent) return;
    window.__webmidiContent = true;

    // --- putting the shim in the page -----------------------------------------
    // Inline first: it runs at once, before any of the page's scripts, so a
    // site that looks for requestMIDIAccess while loading finds it.  A page
    // whose Content-Security-Policy refuses inline script gets the file
    // instead, which runs a moment later.  (Safari does not support
    // "world": "MAIN" in the manifest.)
    var SHIM_SOURCE = "// The Web MIDI API for Safari, in the page's own world.\n//\n// A port of Chromium's Blink module third_party/blink/renderer/modules/webmidi\n// (navigator_web_midi.cc, midi_access_initializer.cc, midi_access.cc,\n// midi_port.cc, midi_input.cc, midi_output.cc and the IDL files beside them),\n// at the commit named in README.md.  Copyright 2013 The Chromium Authors and\n// Google Inc.; use of the ported code is governed by a BSD-style license that\n// can be found in third_party/chromium/LICENSE.\n//\n// Where Blink talks to the browser process over Mojo, this talks to\n// content.js over a MessageChannel, and content.js to the extension's\n// background page, which holds the permission and reaches CoreMIDI through\n// the app extension.  Behaviour follows Chrome's rather than the letter of\n// the spec wherever the two part, since that is what sites are tested with;\n// the exceptions are marked.\n(function () {\n    'use strict';\n    var root = window;\n    // Tells content.js the inline copy ran, so it need not load the file.\n    var me = document.currentScript;\n    if (me && !me.src && document.documentElement) document.documentElement.setAttribute('data-webmidi', '');\n    if (!root.isSecureContext) return;                  // [SecureContext]\n    if (root.navigator && 'requestMIDIAccess' in root.navigator) return;\n\n    var TOKEN = {};                                      // \"Illegal constructor\" unless ours\n\n    // --- the channel to content.js -------------------------------------------\n    var channel = null, nextId = 0, pending = new Map(), listeners = new Map();\n    function connect() {\n        if (channel) return channel;\n        var mc = new MessageChannel();\n        channel = mc.port1;\n        channel.onmessage = function (e) {\n            var m = e.data;\n            if (!m) return;\n            if (m.event) {\n                var fn = listeners.get(m.event);\n                if (fn) fn(m.value);\n                return;\n            }\n            var p = pending.get(m.id);\n            if (!p) return;\n            pending.delete(m.id);\n            if (m.ok) p.resolve(m.value);\n            else p.reject(m.error || { name: 'AbortError', message: 'The MIDI system failed to start.' });\n        };\n        root.postMessage({ __webmidi_connect: 1 }, '*', [mc.port2]);\n        return channel;\n    }\n    function call(op, args) {\n        connect();\n        return new Promise(function (resolve, reject) {\n            var id = ++nextId;\n            pending.set(id, { resolve: resolve, reject: reject });\n            channel.postMessage({ id: id, op: op, args: args });\n        });\n    }\n    function post(op, args) { connect(); channel.postMessage({ op: op, args: args }); }\n\n    function domException(name, message) { return new DOMException(message, name); }\n    function nextTask(fn) {\n        // A task, as Blink's PostTask on kMiscPlatformAPI; not a microtask.\n        var mc = new MessageChannel();\n        mc.port1.onmessage = function () { mc.port1.close(); fn(); };\n        mc.port2.postMessage(0);\n    }\n\n    // --- WebIDL helpers --------------------------------------------------------\n    function brand(obj, Cls, what) {\n        if (!(obj instanceof Cls) || !obj.__webmidi) {\n            throw new TypeError(\"Illegal invocation\" + (what ? \": '\" + what + \"'\" : ''));\n        }\n    }\n    // Makes a class's prototype members look like WebIDL's: enumerable, with\n    // the interface's toStringTag.\n    function idl(Cls, name) {\n        var proto = Cls.prototype;\n        Object.getOwnPropertyNames(proto).forEach(function (k) {\n            if (k === 'constructor') return;\n            var d = Object.getOwnPropertyDescriptor(proto, k);\n            d.enumerable = true;\n            Object.defineProperty(proto, k, d);\n        });\n        Object.defineProperty(proto, Symbol.toStringTag, { value: name, configurable: true });\n        Object.defineProperty(Cls, 'name', { value: name, configurable: true });\n    }\n    function eventHandler(Cls, type, onSet) {\n        var key = '__on' + type;\n        var get = function () { brand(this, Cls, 'on' + type); return this[key] || null; };\n        var set = function (f) {\n            brand(this, Cls, 'on' + type);\n            var fn = (typeof f === 'function' || (f && typeof f === 'object')) ? f : null;\n            if (onSet) onSet.call(this, fn);\n            if (this[key]) this.removeEventListener(type, this[key]);\n            Object.defineProperty(this, key, { value: fn, writable: true, configurable: true });\n            if (fn) EventTarget.prototype.addEventListener.call(this, type, fn);\n        };\n        Object.defineProperty(get, 'name', { value: 'get on' + type });\n        Object.defineProperty(set, 'name', { value: 'set on' + type });\n        Object.defineProperty(Cls.prototype, 'on' + type, { get: get, set: set, enumerable: true, configurable: true });\n    }\n    // WebIDL lengths: the count of required arguments.\n    function lengths(obj, map) {\n        Object.keys(map).forEach(function (k) {\n            var target = k === '' ? obj : obj.prototype[k];\n            Object.defineProperty(target, 'length', { value: map[k], configurable: true });\n        });\n    }\n    function hidden(obj, props) {\n        Object.keys(props).forEach(function (k) {\n            Object.defineProperty(obj, k, { value: props[k], writable: true, configurable: true });\n        });\n    }\n\n    // --- events ----------------------------------------------------------------\n    class MIDIMessageEvent extends Event {\n        constructor(type, init) {\n            if (arguments.length < 1) throw new TypeError(\"Failed to construct 'MIDIMessageEvent': 1 argument required, but only 0 present.\");\n            if (init !== undefined && init !== null && typeof init !== 'object') {\n                throw new TypeError(\"Failed to construct 'MIDIMessageEvent': The provided value is not of type 'MIDIMessageEventInit'.\");\n            }\n            super(String(type), init || undefined);\n            var data = init && init.data !== undefined ? init.data : null;\n            if (data !== null && !(data instanceof Uint8Array)) {\n                throw new TypeError(\"Failed to construct 'MIDIMessageEvent': Failed to read the 'data' property from 'MIDIMessageEventInit': The provided value is not of type 'Uint8Array'.\");\n            }\n            hidden(this, { __data: data, __webmidi: true });\n        }\n        get data() { brand(this, MIDIMessageEvent, 'data'); return this.__data; }\n    }\n    idl(MIDIMessageEvent, 'MIDIMessageEvent');\n    lengths(MIDIMessageEvent, { '': 1 });\n\n    class MIDIConnectionEvent extends Event {\n        constructor(type, init) {\n            if (arguments.length < 1) throw new TypeError(\"Failed to construct 'MIDIConnectionEvent': 1 argument required, but only 0 present.\");\n            if (init !== undefined && init !== null && typeof init !== 'object') {\n                throw new TypeError(\"Failed to construct 'MIDIConnectionEvent': The provided value is not of type 'MIDIConnectionEventInit'.\");\n            }\n            super(String(type), init || undefined);\n            var port = init && init.port !== undefined ? init.port : null;\n            if (port !== null && !(port instanceof MIDIPort)) {\n                throw new TypeError(\"Failed to construct 'MIDIConnectionEvent': Failed to read the 'port' property from 'MIDIConnectionEventInit': Failed to convert value to 'MIDIPort'.\");\n            }\n            hidden(this, { __port: port, __webmidi: true });\n        }\n        get port() { brand(this, MIDIConnectionEvent, 'port'); return this.__port; }\n    }\n    idl(MIDIConnectionEvent, 'MIDIConnectionEvent');\n    lengths(MIDIConnectionEvent, { '': 1 });\n\n    function connectionEvent(port) {\n        return new MIDIConnectionEvent('statechange', { port: port });   // bubbles: no\n    }\n    function messageEvent(bytes, timeStamp) {\n        var e = new MIDIMessageEvent('midimessage', { data: bytes, bubbles: true });\n        // Blink stamps the event with the MIDI time, not its creation time.\n        Object.defineProperty(e, 'timeStamp', { value: timeStamp, configurable: true });\n        return e;\n    }\n\n    // --- MIDIPort (midi_port.cc) -----------------------------------------------\n    class MIDIPort extends EventTarget {\n        constructor(token) {\n            if (token !== TOKEN) throw new TypeError('Illegal constructor');\n            super();\n        }\n        get connection() { brand(this, MIDIPort, 'connection'); return this.__connection; }\n        get id() { brand(this, MIDIPort, 'id'); return this.__id; }\n        get manufacturer() { brand(this, MIDIPort, 'manufacturer'); return this.__manufacturer; }\n        get name() { brand(this, MIDIPort, 'name'); return this.__name; }\n        get state() { brand(this, MIDIPort, 'state'); return this.__state; }\n        get type() { brand(this, MIDIPort, 'type'); return this.__type; }\n        get version() { brand(this, MIDIPort, 'version'); return this.__version; }\n        open() {\n            try { brand(this, MIDIPort, 'open'); } catch (e) { return Promise.reject(e); }\n            var self = this;\n            if (this.__connection === 'open') return Promise.resolve(this);\n            this.__runningOpen++;\n            return new Promise(function (resolve) {\n                nextTask(function () { self.__openAsynchronously(); resolve(self); });\n            });\n        }\n        close() {\n            try { brand(this, MIDIPort, 'close'); } catch (e) { return Promise.reject(e); }\n            var self = this;\n            if (this.__connection === 'closed') return Promise.resolve(this);\n            return new Promise(function (resolve) {\n                nextTask(function () {\n                    self.__setStates(self.__state, 'closed');\n                    resolve(self);\n                });\n            });\n        }\n    }\n    eventHandler(MIDIPort, 'statechange');\n    idl(MIDIPort, 'MIDIPort');\n    lengths(MIDIPort, { '': 0 });\n\n    function initPort(port, access, info, type) {\n        hidden(port, {\n            __webmidi: true, __access: access, __type: type,\n            __id: String(info.id), __manufacturer: info.manufacturer || '', __name: info.name || '',\n            __version: info.version || '', __state: 'connected', __connection: 'closed',\n            __runningOpen: 0\n        });\n    }\n    // The implicit open that sending, or listening for messages, performs.\n    MIDIPort.prototype.__open = function () {\n        if (this.__connection === 'open' || this.__runningOpen) return;\n        var self = this;\n        this.__runningOpen++;\n        nextTask(function () { self.__openAsynchronously(); });\n    };\n    MIDIPort.prototype.__openAsynchronously = function () {\n        this.__runningOpen--;\n        this.__didOpen(this.__state === 'connected');\n        this.__setStates(this.__state, this.__state === 'disconnected' ? 'pending' : 'open');\n    };\n    MIDIPort.prototype.__didOpen = function () {};\n    MIDIPort.prototype.__setStates = function (state, connection) {\n        if (this.__state === state && this.__connection === connection) return;\n        this.__state = state;\n        this.__connection = connection;\n        this.dispatchEvent(connectionEvent(this));\n        this.__access.dispatchEvent(connectionEvent(this));\n    };\n    // The device came or went (MIDIPort::SetState).\n    MIDIPort.prototype.__setState = function (state) {\n        if (state === 'disconnected') {\n            this.__setStates('disconnected', this.__connection === 'closed' ? 'closed' : 'pending');\n        } else if (this.__connection === 'pending') {\n            this.__state = 'connected';          // open() dispatches the one event\n            this.__open();\n        } else {\n            this.__setStates('connected', this.__connection);\n        }\n    };\n    [MIDIPort.prototype].forEach(function (p) {\n        ['__open', '__openAsynchronously', '__didOpen', '__setStates', '__setState'].forEach(function (k) {\n            Object.defineProperty(p, k, { enumerable: false });\n        });\n    });\n\n    // --- MIDIInput (midi_input.cc) ---------------------------------------------\n    class MIDIInput extends MIDIPort {\n        constructor(token) { super(token); }\n        addEventListener(type, listener, options) {\n            EventTarget.prototype.addEventListener.call(this, type, listener, options);\n            if (String(type) === 'midimessage' && this instanceof MIDIInput) this.__open();\n        }\n    }\n    eventHandler(MIDIInput, 'midimessage', function () { this.__open(); });\n    idl(MIDIInput, 'MIDIInput');\n    lengths(MIDIInput, { '': 0 });\n    // Not part of the interface: the override is how Blink's\n    // AddedEventListener hook shows through, so keep it off enumeration.\n    Object.defineProperty(MIDIInput.prototype, 'addEventListener', { enumerable: false });\n    MIDIInput.prototype.__receive = function (bytes, timeStamp) {\n        if (!bytes.length || this.__connection !== 'open') return;\n        if (bytes[0] === 0xf0 && !this.__access.__sysex) return;\n        this.dispatchEvent(messageEvent(bytes, timeStamp));\n    };\n\n    // --- MIDIOutput (midi_output.cc) -------------------------------------------\n    // MessageValidator, with Blink's messages.\n    function validate(data, sysexEnabled) {\n        var offset = 0, n = data.length;\n        function at() { return 'at index ' + offset + ' (' + data[offset] + ').'; }\n        function isReserved(b) { return b === 0xf4 || b === 0xf5 || b === 0xf9 || b === 0xfd; }\n        function acceptRealTime() {\n            for (; offset < n; offset++) {\n                if (data[offset] >= 0xf8 && !isReserved(data[offset])) continue;\n                return true;\n            }\n            return false;\n        }\n        var CHANNEL = [3, 3, 3, 3, 2, 2, 3], SYSTEM = [2, 3, 2, 0, 0, 1, 0];\n        while (offset < n && acceptRealTime()) {\n            var b = data[offset];\n            if (!(b & 0x80)) throw new TypeError('Running status is not allowed ' + at());\n            if (b === 0xf7) throw new TypeError('Unexpected end of system exclusive message ' + at());\n            if (isReserved(b)) throw new TypeError('Reserved status is not allowed ' + at());\n            if (b === 0xf0) {\n                if (!sysexEnabled) throw domException('NotAllowedError', 'System exclusive message is not allowed ' + at());\n                var ended = false;\n                for (offset++; offset < n; offset++) {\n                    var c = data[offset];\n                    if (isReserved(c)) break;\n                    if (c >= 0xf8) continue;\n                    if (c === 0xf7) { offset++; ended = true; break; }\n                    if (c & 0x80) break;\n                }\n                if (!ended) {\n                    if (offset >= n) throw new TypeError('System exclusive message is not ended by end of system exclusive message.');\n                    throw new TypeError('System exclusive message contains a status byte ' + at());\n                }\n                continue;\n            }\n            var length = b >= 0xf0 ? SYSTEM[b - 0xf1] : CHANNEL[(b >> 4) - 8];\n            offset++;\n            if (length === 1) continue;\n            var ok = false;\n            for (var count = 1; offset < n; offset++) {\n                var d = data[offset];\n                if (isReserved(d)) break;\n                if (d >= 0xf8) continue;\n                if (d & 0x80) break;\n                if (++count === length) { offset++; ok = true; break; }\n            }\n            if (!ok) {\n                if (offset >= n) throw new TypeError('Message is incomplete.');\n                throw new TypeError('Unexpected status byte ' + at());\n            }\n        }\n    }\n    function toUint32(v) {\n        var x = Number(v);\n        if (!isFinite(x)) return 0;\n        x = Math.trunc(x) % 4294967296;\n        return x < 0 ? x + 4294967296 : x;\n    }\n    // The send(Uint8Array) and send(sequence<unsigned long>) overloads.\n    function bytesOf(data) {\n        if (data instanceof Uint8Array) return new Uint8Array(data);\n        if (data === null || (typeof data !== 'object' && typeof data !== 'function') ||\n            typeof data[Symbol.iterator] !== 'function') {\n            throw new TypeError(\"Failed to execute 'send' on 'MIDIOutput': The provided value cannot be converted to a sequence.\");\n        }\n        var values = [], i = 0;\n        for (var v of data) {\n            var u = toUint32(v);\n            if (u > 0xff) throw new TypeError('The value at index ' + i + ' (' + u + ') is greater than 0xFF.');\n            values.push(u);\n            i++;\n        }\n        return new Uint8Array(values);\n    }\n\n    class MIDIOutput extends MIDIPort {\n        constructor(token) { super(token); }\n        send(data, timestamp) {\n            brand(this, MIDIOutput, 'send');\n            if (arguments.length < 1) throw new TypeError(\"Failed to execute 'send' on 'MIDIOutput': 1 argument required, but only 0 present.\");\n            var bytes = bytesOf(data);\n            var ms = 0;\n            if (timestamp !== undefined) {\n                ms = Number(timestamp);\n                if (!isFinite(ms)) throw new TypeError(\"Failed to execute 'send' on 'MIDIOutput': The provided double value is non-finite.\");\n            }\n            // Blink: 0 means now; anything else is relative to the time origin.\n            var wall = ms === 0 ? 0 : root.performance.timeOrigin + ms;\n            // Implicit open, even when the data turns out to be invalid.\n            this.__open();\n            validate(bytes, this.__access.__sysex);\n            if (this.__runningOpen) this.__pendingData.push([bytes, wall]);\n            else this.__access.__sendMIDIData(this, bytes, wall);\n        }\n        // Not in Chrome (its IDL still has \"TODO: implement void clear()\");\n        // the spec and Firefox have it.  Drops what has not been sent yet.\n        clear() {\n            brand(this, MIDIOutput, 'clear');\n            this.__pendingData = [];\n            hub.clear(this.__id);\n        }\n    }\n    idl(MIDIOutput, 'MIDIOutput');\n    lengths(MIDIOutput, { '': 0, send: 1 });\n    MIDIOutput.prototype.__didOpen = function (opened) {\n        var queued = this.__pendingData;\n        this.__pendingData = [];\n        if (!opened) return;\n        var self = this;\n        queued.forEach(function (q) { self.__access.__sendMIDIData(self, q[0], q[1]); });\n    };\n    Object.defineProperty(MIDIOutput.prototype, '__didOpen', { enumerable: false });\n\n    // --- the maps (midi_port_map.h) --------------------------------------------\n    function makeMap(name) {\n        class PortMap {\n            constructor(token) {\n                if (token !== TOKEN) throw new TypeError('Illegal constructor');\n                hidden(this, { __webmidi: true, __map: new Map() });\n            }\n            get size() { brand(this, PortMap, 'size'); return this.__map.size; }\n            entries() { brand(this, PortMap, 'entries'); return this.__map.entries(); }\n            keys() { brand(this, PortMap, 'keys'); return this.__map.keys(); }\n            values() { brand(this, PortMap, 'values'); return this.__map.values(); }\n            get(key) { brand(this, PortMap, 'get'); return this.__map.get(String(key)); }\n            has(key) { brand(this, PortMap, 'has'); return this.__map.has(String(key)); }\n            forEach(callback, thisArg) {\n                brand(this, PortMap, 'forEach');\n                if (typeof callback !== 'function') throw new TypeError(\"Failed to execute 'forEach' on '\" + name + \"': The callback provided as parameter 1 is not a function.\");\n                var self = this;\n                this.__map.forEach(function (v, k) { callback.call(thisArg, v, k, self); });\n            }\n        }\n        idl(PortMap, name);\n        lengths(PortMap, { '': 0, forEach: 1 });\n        Object.defineProperty(PortMap.prototype, Symbol.iterator, {\n            value: PortMap.prototype.entries, writable: true, configurable: true\n        });\n        return PortMap;\n    }\n    var MIDIInputMap = makeMap('MIDIInputMap');\n    var MIDIOutputMap = makeMap('MIDIOutputMap');\n    // CreatePortMap: a new map each time, of the ports that are not\n    // disconnected; ports sharing an id make it empty.\n    function portMap(Cls, list) {\n        var map = new Cls(TOKEN), ids = new Set(), ports = [];\n        list.forEach(function (p) {\n            if (p.__state !== 'disconnected') { ports.push(p); ids.add(p.__id); }\n        });\n        if (ports.length === ids.size) ports.forEach(function (p) { map.__map.set(p.__id, p); });\n        return map;\n    }\n\n    // --- MIDIAccess (midi_access.cc) -------------------------------------------\n    class MIDIAccess extends EventTarget {\n        constructor(token) {\n            if (token !== TOKEN) throw new TypeError('Illegal constructor');\n            super();\n        }\n        get inputs() { brand(this, MIDIAccess, 'inputs'); return portMap(MIDIInputMap, this.__inputs); }\n        get outputs() { brand(this, MIDIAccess, 'outputs'); return portMap(MIDIOutputMap, this.__outputs); }\n        get sysexEnabled() { brand(this, MIDIAccess, 'sysexEnabled'); return this.__sysex; }\n    }\n    eventHandler(MIDIAccess, 'statechange');\n    idl(MIDIAccess, 'MIDIAccess');\n    lengths(MIDIAccess, { '': 0 });\n\n    function newAccess(sysex, list) {\n        var access = new MIDIAccess(TOKEN);\n        hidden(access, { __webmidi: true, __sysex: sysex, __inputs: [], __outputs: [] });\n        (list.inputs || []).forEach(function (info) { addPort(access, 'input', info, false); });\n        (list.outputs || []).forEach(function (info) { addPort(access, 'output', info, false); });\n        return access;\n    }\n    function addPort(access, type, info, announce) {\n        var port = new (type === 'input' ? MIDIInput : MIDIOutput)(TOKEN);\n        initPort(port, access, info, type);\n        if (type === 'output') hidden(port, { __pendingData: [] });\n        (type === 'input' ? access.__inputs : access.__outputs).push(port);\n        // DidAddInputPort: the event goes to the access only.\n        if (announce) access.dispatchEvent(connectionEvent(port));\n        return port;\n    }\n    MIDIAccess.prototype.__sendMIDIData = function (port, bytes, wall) {\n        if (!bytes.length) return;\n        hub.send(port.__id, bytes, wall);\n    };\n    // The system's port list now; ports are matched by id and never removed.\n    MIDIAccess.prototype.__update = function (list) {\n        var self = this;\n        [['input', this.__inputs, list.inputs || []], ['output', this.__outputs, list.outputs || []]].forEach(function (s) {\n            var now = new Map();\n            s[2].forEach(function (info) { now.set(String(info.id), info); });\n            s[1].forEach(function (port) {\n                var there = now.has(port.__id);\n                if (there && port.__state === 'disconnected') port.__setState('connected');\n                if (!there && port.__state !== 'disconnected') port.__setState('disconnected');\n                now.delete(port.__id);\n            });\n            now.forEach(function (info) { addPort(self, s[0], info, true); });\n        });\n    };\n    ['__sendMIDIData', '__update'].forEach(function (k) {\n        Object.defineProperty(MIDIAccess.prototype, k, { enumerable: false });\n    });\n\n    // --- the hub: one per document, for every MIDIAccess in it ------------------\n    var accesses = [];\n    var hub = {\n        gen: null, cursor: -1, polling: false, queue: [], inflight: false, unacked: 0,\n        // MIDIDispatcher's kMaxUnacknowledgedBytesSent.\n        MAX_UNACKED: 10 * 1024 * 1024,\n        send: function (id, bytes, wall) {\n            if (this.MAX_UNACKED - this.unacked < bytes.length) return;\n            this.unacked += bytes.length;\n            this.queue.push([id, bytes, wall]);\n            this.flush();\n        },\n        clear: function (id) {\n            this.queue = this.queue.filter(function (q) { return q[0] !== id; });\n            post('clear', { port: id });\n        },\n        // One batch in flight at a time, so the order is the order sent.\n        flush: function () {\n            if (this.inflight || !this.queue.length) return;\n            var batch = this.queue, self = this;\n            this.queue = [];\n            this.inflight = true;\n            var size = batch.reduce(function (a, q) { return a + q[1].length; }, 0);\n            call('send', { msgs: batch }).catch(function () {}).then(function () {\n                self.unacked -= size;\n                self.inflight = false;\n                self.flush();\n            });\n        },\n        ports: function () {\n            var self = this;\n            return call('ports').then(function (list) {\n                self.gen = list.gen;\n                accesses.forEach(function (a) { a.__update(list); });\n                return list;\n            });\n        },\n        poll: function () {\n            if (this.polling) return;\n            this.polling = true;\n            var self = this;\n            (function next() {\n                call('recv', { since: self.cursor, gen: self.gen, wait: 1000 }).then(function (r) {\n                    self.cursor = r.seq;\n                    var origin = root.performance.timeOrigin;\n                    (r.events || []).forEach(function (ev) {\n                        var id = String(ev[0]), ts = ev[2] - origin;\n                        accesses.forEach(function (a) {\n                            a.__inputs.forEach(function (p) {\n                                if (p.__id === id) p.__receive(new Uint8Array(ev[1]), ts);\n                            });\n                        });\n                    });\n                    if (r.gen !== self.gen) return self.ports().then(next, next);\n                    next();\n                }, function () { root.setTimeout(next, 1000); });\n            })();\n        }\n    };\n\n    // --- navigator.requestMIDIAccess (navigator_web_midi.cc) --------------------\n    function requestMIDIAccess(options) {\n        if (!(this instanceof Navigator)) {\n            return Promise.reject(new TypeError(\"Illegal invocation\"));\n        }\n        if (options !== undefined && options !== null && typeof options !== 'object' && typeof options !== 'function') {\n            return Promise.reject(new TypeError(\"Failed to execute 'requestMIDIAccess' on 'Navigator': The provided value is not of type 'MIDIOptions'.\"));\n        }\n        // MIDIOptions, read as WebIDL reads a dictionary: members in order.\n        // `software` asks for software synthesizers; macOS has none that\n        // appear as MIDI ports, so it is read and changes nothing.\n        var software = options ? !!options.software : false;\n        var sysex = options ? !!options.sysex : false;\n        void software;\n        return call('request', { sysex: sysex }).then(function () {\n            return hub.ports();\n        }, function (err) {\n            throw domException(err.name || 'NotAllowedError', err.message || 'Permission to use Web MIDI API was not granted.');\n        }).then(function (list) {\n            var access = newAccess(sysex, list);\n            accesses.push(access);\n            hub.poll();\n            return access;\n        }, function (err) {\n            if (err instanceof DOMException) throw err;\n            if (err && err.name === 'InvalidStateError') throw domException('InvalidStateError', 'Platform dependent initialization failed.');\n            throw domException('AbortError', 'The MIDI system failed to start.');\n        });\n    }\n    Object.defineProperty(requestMIDIAccess, 'length', { value: 0 });\n    Object.defineProperty(Navigator.prototype, 'requestMIDIAccess', {\n        value: requestMIDIAccess, writable: true, enumerable: true, configurable: true\n    });\n\n    // --- the Permissions API (spec 4.1) -------------------------------------------\n    // navigator.permissions.query({name: \"midi\", sysex}), as Chrome answers\n    // it.  Safari's Permissions API rejects names it does not know, so \"midi\"\n    // is answered here and anything else goes to Safari.  The status is a\n    // real EventTarget with PermissionStatus.prototype, so instanceof and\n    // addEventListener work; it fires \"change\" when the decision changes.\n    var statuses = [];\n    function permissionStatus(sysex, state) {\n        var st = new EventTarget();\n        Object.setPrototypeOf(st, root.PermissionStatus.prototype);\n        hidden(st, { __state: state, __sysex: sysex, __onchange: null });\n        Object.defineProperties(st, {\n            state: { get: function () { return st.__state; }, enumerable: true, configurable: true },\n            name: { value: 'midi', enumerable: true, configurable: true },\n            onchange: {\n                get: function () { return st.__onchange; },\n                set: function (f) {\n                    if (st.__onchange) st.removeEventListener('change', st.__onchange);\n                    st.__onchange = typeof f === 'function' ? f : null;\n                    if (st.__onchange) st.addEventListener('change', st.__onchange);\n                },\n                enumerable: true, configurable: true\n            }\n        });\n        statuses.push(st);\n        return st;\n    }\n    listeners.set('permissionchange', function () {\n        statuses.forEach(function (st) {\n            call('permission', { sysex: st.__sysex }).then(function (state) {\n                if (state !== st.__state) { st.__state = state; st.dispatchEvent(new Event('change')); }\n            }, function () {});\n        });\n    });\n    if (root.Permissions && root.Permissions.prototype.query) {\n        var safariQuery = root.Permissions.prototype.query;\n        var query = function query(descriptor) {\n            if (descriptor && typeof descriptor === 'object' && descriptor.name === 'midi') {\n                var sysex = !!descriptor.sysex;\n                return call('permission', { sysex: sysex }).then(function (state) {\n                    return permissionStatus(sysex, state);\n                }, function () { return permissionStatus(sysex, 'denied'); });\n            }\n            return safariQuery.apply(this, arguments);\n        };\n        Object.defineProperty(query, 'length', { value: 1 });\n        Object.defineProperty(root.Permissions.prototype, 'query', {\n            value: query, writable: true, enumerable: true, configurable: true\n        });\n    }\n\n    [['MIDIAccess', MIDIAccess], ['MIDIPort', MIDIPort], ['MIDIInput', MIDIInput], ['MIDIOutput', MIDIOutput],\n     ['MIDIInputMap', MIDIInputMap], ['MIDIOutputMap', MIDIOutputMap],\n     ['MIDIMessageEvent', MIDIMessageEvent], ['MIDIConnectionEvent', MIDIConnectionEvent]\n    ].forEach(function (c) {\n        Object.defineProperty(root, c[0], { value: c[1], writable: true, configurable: true, enumerable: false });\n    });\n})();\n";
    function inject() {
        var parent = document.head || document.documentElement;
        if (!parent || !window.isSecureContext) return;
        var s = document.createElement('script');
        s.textContent = SHIM_SOURCE + '\n//# sourceURL=webmidi-shim.js';
        parent.appendChild(s);
        s.remove();
        if (document.documentElement.hasAttribute('data-webmidi')) {
            document.documentElement.removeAttribute('data-webmidi');
            return;
        }
        var f = document.createElement('script');
        f.src = browser.runtime.getURL('shim.js');
        f.onload = f.onerror = function () { f.remove(); };
        parent.appendChild(f);
    }
    inject();

    // --- base64 ----------------------------------------------------------------
    function toBase64(bytes) {
        var s = '';
        for (var i = 0; i < bytes.length; i += 0x8000) {
            s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
        }
        return btoa(s);
    }
    function fromBase64(b64) {
        var s = atob(b64), out = new Uint8Array(s.length);
        for (var i = 0; i < s.length; i++) out[i] = s.charCodeAt(i);
        return out;
    }

    // --- Permissions Policy for frames ---------------------------------------
    // The "midi" feature's default allowlist is 'self' (spec 4.2): a frame
    // may use MIDI when its container allows it and every container above
    // it does too.  Only the parent document can read an <iframe>'s allow
    // attribute, so the background asks the tab's frames which one holds
    // the frame in question (runtime.getFrameId), and that one answers.
    // All of it goes through the extension; nothing is posted where the
    // page's own message listeners would see it.
    // Whether an <iframe>'s allow attribute lets `child` use MIDI, by the
    // Permissions Policy rules: "midi" alone means the frame's src origin.
    function allows(frame, child) {
        var self = location.origin, src = null, list = null;
        try { src = new URL(frame.getAttribute('src') || 'about:blank', location.href).origin; } catch (e) {}
        (frame.getAttribute('allow') || '').split(';').forEach(function (directive) {
            var t = directive.trim().split(/\s+/).filter(Boolean);
            if (t.length && t[0].toLowerCase() === 'midi') list = t.slice(1);
        });
        if (list === null) return child === self;
        if (!list.length) list = ["'src'"];
        return list.some(function (tok) {
            var k = tok.toLowerCase();
            if (k === '*') return true;
            if (k === "'none'") return false;
            if (k === "'self'") return child === self;
            if (k === "'src'") return child === src;
            try { return new URL(tok).origin === child; } catch (e) { return false; }
        });
    }
    browser.runtime.onMessage.addListener(function (msg) {
        if (!msg || msg.type !== 'policy') return undefined;
        var frame = Array.prototype.find.call(document.querySelectorAll('iframe, frame'), function (f) {
            try { return browser.runtime.getFrameId(f) === msg.frameId; } catch (e) { return false; }
        });
        if (!frame) return undefined;          // not ours: the frame that holds it answers
        if (!allows(frame, msg.origin)) return Promise.resolve(false);
        // And this document must be allowed itself.
        return window === window.top ? Promise.resolve(true)
            : browser.runtime.sendMessage({ type: 'policy-self' }).then(function (r) { return r === true; });
    });

    function ask(msg) { return browser.runtime.sendMessage(msg); }
    function native(req) {
        return ask({ type: 'native', req: req }).then(function (r) {
            if (!r || r.error) throw r && r.error ? r.error : { name: 'AbortError', message: 'The MIDI system failed to start.' };
            return r.value;
        });
    }

    // --- the shim's channel ----------------------------------------------------
    window.addEventListener('message', function (e) {
        if (e.source !== window || !e.data || !e.data.__webmidi_connect || !e.ports || !e.ports[0]) return;
        e.stopImmediatePropagation();
        serve(e.ports[0]);
    }, true);

    var ports = [];
    browser.runtime.onMessage.addListener(function (msg) {
        if (msg && msg.type === 'grants-changed') {
            ports.forEach(function (p) { p.postMessage({ event: 'permissionchange' }); });
        }
        return undefined;
    });

    function serve(port) {
        ports.push(port);
        function answer(id, ok, value, transfer) {
            if (id === undefined) return;
            try { port.postMessage(ok ? { id: id, ok: true, value: value } : { id: id, ok: false, error: value }, transfer || []); }
            catch (err) { port.postMessage({ id: id, ok: false, error: { name: 'AbortError', message: String(err) } }); }
        }
        port.onmessage = function (e) {
            var m = e.data || {}, args = m.args || {};
            var done = function (v, t) { answer(m.id, true, v, t); };
            var fail = function (err) {
                answer(m.id, false, { name: (err && err.name) || 'AbortError', message: (err && err.message) || String(err) });
            };
            switch (m.op) {
            case 'request':
                ask({ type: 'request', sysex: !!args.sysex }).then(function (r) {
                    if (r && r.ok) done(true); else fail(r && r.error);
                }, fail);
                break;
            case 'permission':
                ask({ type: 'permission', sysex: !!args.sysex }).then(done, fail);
                break;
            case 'ports':
                native({ cmd: 'ports' }).then(done, fail);
                break;
            case 'send':
                native({ cmd: 'send', msgs: (args.msgs || []).map(function (q) { return [q[0], toBase64(q[1]), q[2] || 0]; }) })
                    .then(done, fail);
                break;
            case 'clear':
                native({ cmd: 'clear', port: args.port }).then(done, fail);
                break;
            case 'recv':
                native({ cmd: 'recv', since: args.since, gen: args.gen, wait: args.wait }).then(function (r) {
                    var transfer = [];
                    r.events = (r.events || []).map(function (ev) {
                        var bytes = fromBase64(ev[1]);
                        transfer.push(bytes.buffer);
                        return [ev[0], bytes, ev[2]];
                    });
                    done(r, transfer);
                }, fail);
                break;
            default:
                fail({ name: 'NotSupportedError', message: 'Unknown request' });
            }
        };
    }

    // --- the permission prompt (top frame only) ------------------------------
    if (window !== window.top) return;

    var TEXT = {
        midi: 'Allow “{site}” to use your MIDI devices?',
        sysex: 'Allow “{site}” to control and reprogram your MIDI devices?',
        sysexDetail: 'This lets the site change your devices’ settings and firmware.',
        allow: 'Allow',
        block: 'Don’t Allow',
        from: 'Web MIDI'
    };
    var ICON = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAQKADAAQAAAABAAAAQAAAAABlmWCKAAAJ0ElEQVR4Ae1aC3CVxRU+EIKl5C3hESEGqYA0IsirEISEMGJAGZRxnKGVcToDFtS2auujLdZpS2tRqi04KtOHMg59anUsD6lAoeGNgoUQCBDCI4FQSEJIQkIe2+/bm/2Tm/vfm/vf/8a5oTkz3//v3T27e87Zs6/zX5Eu6rJAlwW6LPB/bIFuLnRnXQMXzbiuqtCCgePGnBrAKNwDPU0FsoDhQCIQDXyRVI/OyoEjwBZgK9AAhGwM1A1I3VF6A7AYOAuYjiLlTZkoG2WkrGEjjnoUMAI4BESKwv7kONgsK2Wm7K6IDdDdpwNlgL9OIy2fslJmyu7KCLRiOsC5FmlKticPjUDZqUNIxHkUA+QB7XUWqeWcstTB8ZpAt+Gq/h0gUpULVi7qQF0cTQVaLBYoBoLtKFL5qAN1sfUC20wwc95kASlAZyfqQF1s1wI7A9BVuHpmAtcLZUIR2x2BmW3JGGBY2wI3v4fdeotkZ02W7MwMGZw2SLp37w6wK5GmJgU0SeHJ07J56w7ZtCVXjh4rdNNd27rUxRiAU9UijwTWT52gV8QB64CJOsfF4+7sKfK97y6U4UOHyID+faVHDzubt3TQ0NAg585fkCMFJ+SV11bJxk3bWgpDT+1E1ZlAJdDUuhk7aWgUGoErZ8g08KYBsvwXP5IpkydI/37JVjvlFZelZ3S09O79ZSvPJFiWmBAvgwamaNz+1eGyLXe3PP38z+Rs8TnDFsqbulAnnwG3WxjI+CXgYSCkRXDqXV+TP72zUu7KGC9xsTHCUT11ulj+9vd1snTZChmclippNw9E8y20//M8efypJXL1aq02QmxMb4mLi5Xhw4ZIzowsycsvQBtnWyo4S5WA/V2gDvCaAnbN0ChJwN5mZkfb28QJdypVfcrC2WO71YrlP1E3pfS32mm8clLVXDyqqi7kazD96fa1Vjl5f/3yi4p1TVtnCnYpth2KTM26UCe7AUe2N4VsAIy8On10pxa6obJQHdy7Ud05Kt1HaEwJ9eADs9T9s2doPPf0YgW39+EbN+YOdfVSgaq/fMIyBPuAuE7BwexYA2DOq7xPP9GCNlUV6Tfc3KmgPvxs47Md6xS9ht7APtiXQyN0vAH+vPp1xVGnkAd2bVDhUN4oSe/Yv3O9bpt9sC9TFuS7Yw2ArU6dK9ynBSw+vsfNXPWr2IRxo601gX2xzyCVJ1/HGmDjR+9q5evKj6vXlv3YiWCOeH/10hLFPuhl7DMiDIATnrXwnTj0b8UFzoFgjnhxkFLsgwbgYsu+g+zLrwdwz3dF03C05QmPtDV3l5wv/a+r9gJV5glx07+2axb2yaO1W3JtgOkQgsdbnuL++v5aH3kWfnOerP/gHYmOtjt0+rDrjJ49o+XDv/xWHnt0vg/Dex+sl7LyCt3ntKmTfMrDkeHoHMAtii5ZmJfrsz2NGX27Ki36TO/j3BkgXFDgwcns/ekjhnnV4TQ4eXi77pN9B9lmx00B3upIvM0Vl5zXaT7mz5sr+3L/Icl9kvS0ePSJ562y9hKrfr9GSs5dEKWU4DAlj3zjQasKpwGP1iTTt1UYQsL1FDBX2uqaGi0wZeBlZtnSH2hxunXrpg2we+/+oMU7mHdEX35Yl/SHt16RrwxJ02k+qqprdNr0bRWEkHBtANNnVFTLMbuurk7q6/nhxkN1ddeE8zpY4noxMp0fnDxEz6qt5T3GQ1FRHrGNgUx+KG/XBmAwg8RrrHHJ+2ffI7G4BdbUXNVlCx57Vq5dazGIzgzwqK9vkDGT79UcVVXVuq37Zk7Xv6l0XCxDfCKNjV5Xe53n9BEGA3iEoIIpA/rp/t/8zc8lHlfZknOlkpw6Wq8NWCSltuyY4ILjV8bJk8YJFlQN3v9j+42QGF6LYcwlz31b12MfXBtIXHfckmsDnCw6o2VISIiz3DbttklSjXk656EFcvFSmcydM1OSkhL04vXDZx73KzPXDo546YWLMhWBFKaH3pEpl8rKJSP7AV2PQZL4eI8HMITWEeRoG1y04GFry3p71XKfbYlneG6TZqvkNgahFUZWxwT+s+djhemj8zDS6vjBbRa/3f3/d2+8rMu5TS5eON+nP7Ztg47bBjfjZMatiTQlY4IgmKHT5rH0xe+bpD4MMTZIGjVyhHDn4Kjn3J2p8xA7kF69GIzy0Ka1fzRJ/e7Xt49kItpE0qdCBE/dkuspwOgtA5gkKv/sU4u8ZDqcf8z63Te5jxRjXSBxZ+CCxvl86kyxzissOm2tI8xYveY9nW8ezzz5LWGskcQ+wxw5Nt3osJGjkFjb6zAWM8sNN3y42nJprORWfv7+zVb+kQNbrPyZM7JUyYm9umzt+29b+RkTxypetTmVIu46DNPpIIUJiHy+e4MV4qLAjOa8+ssXFLZJSyFznGV5Uf4OK588q1a+pExUiW0zIMKjNHkjMiBCIduGxHhOv2Vwqnpi0SNawT43JllKkn/unBx18cwBdaX0sLo3J9urLHVQikJUWX39oTkKH1G04sYgERsSo1IMWHKUzEhxtOi6LGsLfCHSrszLkr9A5/ixo9Shff+0dhnGAPzxtm2/zW+/uwD4fMjRNojaXspx62II2xiCoe3XX/2p4qi25uUtz/CMTL/Nq4y8rNM6LE5eu22xdZsB0l+cASgER4muatYEvjnneU7gQmiiuowe3ZiUqJXnt4BZ90xTuPho3tZ12VaII28M69cAPp+KoAA9IB74GBgLhETcruw+jVVcrpSKikqc4xv1rY7bYAw+k/EylZgYLwnx/CzpIUaXwvRpbB9anAFcBho9rXuegQzA8I7n1NG6hsN0hHwc3QWxZwGODLAGFWi1sBA/jzN+yBCav8/jvFd8gtMdT5dhPuTQm+cBPgawU46nwwRgJWDmUGd/Uxfq5HPy9ckAE4nzZIdOXR8P6uI1941adgbgaDPoxviz5+BuuDvnmzpQF+pE3bwokAEYeHvTi7tz/qAO1MXWAP5UomH4B8NbAV7nOusaUNCsA3WxG2xk2xO3x2ggGcgBuHp2NiNUNMtOHaiL3Zbf7j8mqPQVgF6QBdwAdAaqhJBPAlz8mGZE1mf+I69d4qmQ7pMKzAaOA5HuCRys+wDKTNmpg18KWNhci6FXWrAc+Aigaw0FegORRIzLrQBeABiiopy1AOX3S7bzog03ebiA0P2pNA/rBI/J44E0gGHa4L9+gjkMxFWd07MI2APwuEt3J6oBfkmh8gFdPxgDoA1NNAI9hobo1QymucAw30lbYHdNVIyHG3onleVXGIJp5gcceZRrcio0+QkqzBEnmHa0xYA/XEQlqSy9gWDarFFItk9ODdC6RWMMN220bi/UtFE4oKuH2nhXvS4LXOcW+B9QFrMKZbG2XAAAAABJRU5ErkJggg==";
    // Safari's Liquid Glass, as near as a page can draw it: a translucent,
    // blurred and saturated panel with a lit edge, and capsule buttons.
    var CSS = [
        ':host{all:initial}',
        '.wrap{position:fixed;top:14px;left:50%;transform:translateX(-50%);z-index:2147483647;',
        'width:max-content;max-width:min(440px,calc(100vw - 32px));box-sizing:border-box;padding:16px 18px 14px;',
        'border-radius:26px;display:grid;grid-template-columns:auto 1fr;column-gap:14px;',
        'font:13px/1.4 -apple-system,system-ui,sans-serif;color:#1d1d1f;',
        'background:rgba(255,255,255,.58);-webkit-backdrop-filter:blur(28px) saturate(190%);backdrop-filter:blur(28px) saturate(190%);',
        'border:.5px solid rgba(255,255,255,.7);',
        'box-shadow:inset 0 1px 0 rgba(255,255,255,.85),inset 0 -1px 1px rgba(255,255,255,.25),0 12px 40px rgba(0,0,0,.22),0 0 0 .5px rgba(0,0,0,.08)}',
        '.icon{width:40px;height:40px;grid-row:1 / span 4;margin-top:2px}',
        '.from{font-size:11px;font-weight:600;color:rgba(60,60,67,.7);margin:0 0 2px}',
        '.q{font-weight:600;font-size:14px;margin:0;overflow-wrap:anywhere}',
        '.d{margin:4px 0 0;color:rgba(60,60,67,.85)}',
        '.b{display:flex;gap:8px;justify-content:flex-end;margin-top:14px;grid-column:2}',
        'button{font:inherit;font-weight:500;padding:6px 16px;border-radius:999px;border:0;cursor:pointer;',
        'transition:transform .12s ease,opacity .2s}',
        'button:active{transform:scale(.97)}button:disabled{opacity:.45;cursor:default}',
        '.no{color:#1d1d1f;background:rgba(255,255,255,.55);',
        'box-shadow:inset 0 1px 0 rgba(255,255,255,.9),inset 0 0 0 .5px rgba(0,0,0,.12)}',
        '.yes{color:#fff;background:#000;box-shadow:inset 0 1px 0 rgba(255,255,255,.28),0 1px 3px rgba(0,0,0,.25)}',
        '@media (prefers-color-scheme:dark){.wrap{color:#f5f5f7;background:rgba(40,40,44,.55);border-color:rgba(255,255,255,.18);',
        'box-shadow:inset 0 1px 0 rgba(255,255,255,.22),0 12px 40px rgba(0,0,0,.5)}',
        '.from{color:rgba(235,235,245,.6)}.d{color:rgba(235,235,245,.8)}',
        '.no{color:#f5f5f7;background:rgba(255,255,255,.12);box-shadow:inset 0 1px 0 rgba(255,255,255,.2),inset 0 0 0 .5px rgba(255,255,255,.12)}',
        '.yes{color:#000;background:#fff}}'
    ].join('');

    var showing = null;
    function prompt(site, sysex) {
        if (showing) return showing;
        showing = new Promise(function (resolve) {
            var host = document.createElement('webmidi-prompt');
            host.setAttribute('style', 'all:initial !important;display:block !important;position:fixed !important;' +
                'inset:0 auto auto 0 !important;z-index:2147483647 !important;opacity:1 !important;visibility:visible !important');
            var shadow = host.attachShadow({ mode: 'closed' });
            var style = document.createElement('style');
            style.textContent = CSS;
            var box = document.createElement('div');
            box.className = 'wrap';
            box.setAttribute('role', 'alertdialog');
            var img = document.createElement('img'); img.className = 'icon'; img.src = ICON; img.alt = '';
            var from = document.createElement('p'); from.className = 'from'; from.textContent = TEXT.from;
            var q = document.createElement('p'); q.className = 'q';
            q.textContent = (sysex ? TEXT.sysex : TEXT.midi).replace('{site}', site);
            box.append(img, from, q);
            if (sysex) { var d = document.createElement('p'); d.className = 'd'; d.textContent = TEXT.sysexDetail; box.append(d); }
            var bar = document.createElement('div'); bar.className = 'b';
            var no = document.createElement('button'); no.className = 'no'; no.textContent = TEXT.block;
            var yes = document.createElement('button'); yes.className = 'yes'; yes.textContent = TEXT.allow;
            bar.append(no, yes); box.append(bar);
            shadow.append(style, box);
            // Buttons wake after a moment, so a click aimed at the page as the
            // prompt appears cannot land on Allow.
            no.disabled = yes.disabled = true;
            setTimeout(function () { no.disabled = yes.disabled = false; }, 500);

            var watcher = new MutationObserver(function () {
                if (!host.isConnected) document.documentElement.appendChild(host);
            });
            function finish(answer) {
                watcher.disconnect();
                document.removeEventListener('keydown', onKey, true);
                host.remove();
                showing = null;
                resolve(answer);
            }
            // Only a real click decides: a page can dispatch clicks, but they
            // are not trusted.
            no.addEventListener('click', function (e) { if (e.isTrusted && !no.disabled) finish('block'); });
            yes.addEventListener('click', function (e) { if (e.isTrusted && !yes.disabled) finish('allow'); });
            function onKey(e) { if (e.isTrusted && e.key === 'Escape') finish('dismiss'); }
            document.addEventListener('keydown', onKey, true);
            (document.body || document.documentElement).appendChild(host);
            watcher.observe(document.documentElement, { childList: true, subtree: true });
        });
        return showing;
    }

    browser.runtime.onMessage.addListener(function (msg) {
        if (msg && msg.type === 'prompt') return prompt(msg.site, !!msg.sysex);
        return undefined;
    });
})();
